package com.botwrecompandroid;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Safe, metadata-only Nintendo container inspector.
 *
 * It recognizes the public container signatures and, for PFS0, lists its
 * directory entries. It intentionally does not process tickets, title keys,
 * prod.keys, encrypted NCA contents, or extract protected game data.
 */
final class NintendoPackageInspector {
    private NintendoPackageInspector() {}

    static String inspectPfs0(InputStream input) throws IOException {
        byte[] header = readExact(input, 16);
        if (header[0] != 'P' || header[1] != 'F' || header[2] != 'S' || header[3] != '0')
            throw new IOException("Assinatura PFS0 não encontrada. O arquivo pode estar compactado ou inválido.");
        long count = u32(header, 4);
        long stringBytes = u32(header, 8);
        if (count > 4096 || stringBytes > 4 * 1024 * 1024)
            throw new IOException("Tabela PFS0 fora dos limites esperados.");
        long entryBytes = count * 0x18L;
        if (entryBytes > 16 * 1024 * 1024)
            throw new IOException("Tabela de arquivos muito grande.");
        byte[] entries = readExact(input, (int) entryBytes);
        byte[] strings = readExact(input, (int) stringBytes);

        List<String> names = new ArrayList<>();
        for (int i = 0; i < (int) count; i++) {
            int at = i * 0x18;
            long offset = u64(entries, at);
            long size = u64(entries, at + 8);
            long nameOffset = u32(entries, at + 16);
            if (offset < 0 || size < 0 || nameOffset >= strings.length)
                throw new IOException("Entrada PFS0 inválida.");
            int end = (int) nameOffset;
            while (end < strings.length && strings[end] != 0) end++;
            if (end == strings.length) throw new IOException("Nome de arquivo PFS0 inválido.");
            String fileName = new String(strings, (int) nameOffset, end - (int) nameOffset, StandardCharsets.UTF_8);
            if (names.size() < 24) names.add(fileName + " (" + size + " bytes)");
        }
        StringBuilder out = new StringBuilder();
        out.append("Contêiner: PFS0 (comumente usado em NSP)\n");
        out.append("Entradas encontradas: ").append(count).append('\n');
        out.append("Nomes iniciais:\n");
        for (String name : names) out.append("• ").append(name).append('\n');
        if (count > names.size()) out.append("… e mais ").append(count - names.size()).append(" entradas.\n");
        out.append("\nApenas a estrutura pública do contêiner foi lida. Conteúdo NCA protegido não foi aberto.");
        return out.toString();
    }

    static String inspectXci(InputStream input) throws IOException {
        skipFully(input, 0x100);
        byte[] magic = readExact(input, 4);
        if (magic[0] != 'H' || magic[1] != 'E' || magic[2] != 'A' || magic[3] != 'D')
            throw new IOException("Assinatura HEAD do cabeçalho XCI não encontrada.");
        return "Contêiner: XCI\nAssinatura: HEAD (válida)\n" +
                "O cabeçalho principal foi reconhecido. A listagem de partições e o conteúdo protegido " +
                "não são processados nesta versão.";
    }

    private static byte[] readExact(InputStream in, int length) throws IOException {
        byte[] data = new byte[length];
        int done = 0;
        while (done < length) {
            int n = in.read(data, done, length - done);
            if (n < 0) throw new IOException("Arquivo truncado: dados insuficientes.");
            if (n == 0) continue;
            done += n;
        }
        return data;
    }

    private static void skipFully(InputStream in, long count) throws IOException {
        long left = count;
        while (left > 0) {
            long n = in.skip(left);
            if (n <= 0) {
                if (in.read() < 0) throw new IOException("Arquivo truncado antes do cabeçalho XCI.");
                n = 1;
            }
            left -= n;
        }
    }

    private static long u32(byte[] b, int p) {
        return ((long)b[p] & 255) | (((long)b[p + 1] & 255) << 8) |
                (((long)b[p + 2] & 255) << 16) | (((long)b[p + 3] & 255) << 24);
    }

    private static long u64(byte[] b, int p) {
        long lo = u32(b, p), hi = u32(b, p + 4);
        if ((hi & 0x80000000L) != 0) return -1;
        return lo | (hi << 32);
    }
}
