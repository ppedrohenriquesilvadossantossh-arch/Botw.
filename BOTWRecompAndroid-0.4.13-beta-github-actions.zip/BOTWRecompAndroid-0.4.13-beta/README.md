# BOTWRecompAndroid

**English** | [Português](README.pt-BR.md)

[![Listed on PlayPorted](https://playported.com/badge.svg)](https://playported.com/ports/754-the-legend-of-zelda-breath-of-the-wild/)

A port of *The Legend of Zelda: Breath of the Wild* (Nintendo Switch, versions **1.0.0, 1.6.0, 1.8.2 and 1.9.0**) for
Android. This is **not Switch emulation**: the game code can be recompiled into C for the phone or, in the experimental
Native Mode, run directly on its ARM64 CPU. The game's graphics API (NVN) is translated to Vulkan.

It is built on the engine of **[LAS Recomp](https://github.com/peiikai/LASRecomp)** by peiikai (a recompilation of
*Link's Awakening*) and its Android port, **[LASRecompAndroid](https://github.com/mamcjr/LASRecompAndroid)**.

> [!WARNING]
> **Beta.** Tested primarily on one phone (POCO F7 Ultra, Adreno 830, Mesa Turnip driver). Performance and compatibility
> vary by device; expect bugs, especially on GPUs that have not been tested on physical hardware. See the
> [0.4.13-beta release notes](https://github.com/mamcjr/BOTWRecompAndroid/releases/tag/v0.4.13-beta) and the
> [development notes](docs/BOTW-PORT.md) (in Portuguese).

## Supported platform

Android is the only application target. Desktop ports and packaging were discontinued on 2026-10-22.
Windows, Linux or macOS may still be used as development hosts with the Android SDK/NDK.

## Status

- **Playable** from the title screen into the world, with saves, on the tested POCO F7 Ultra. All four listed game
  versions are supported in Recompiled Mode. Native Mode has been tested with 1.0.0 and 1.9.0; 1.6.0 and 1.8.2 still
  need testing in that mode.
- **Game code:** choose Recompiled Mode (build the code once on the phone) or experimental Native Mode (skip that
  build). You can switch a Recompiled setup to Native Mode later.
- **Game files:** copy the extracted files into app storage or, since **0.2.3-beta**, use them in place without an
  additional copy of about 16 GB. In-place use requires Android all-files access and the source folder must remain
  available.
- **DLC, saves and mods:** install your own extracted Expansion Pass data; import and export saves as ZIP or import an
  emulator save folder; use mods, including mods that add files and DLC mod folders. In-place mod use needs more testing.
- **Video and controls:** optional 60 fps on supported game versions and experimental 60 fps in-engine cutscenes,
  unlocked aspect ratio, internal/output resolution, FSR 1 or Snapdragon GSR 1 upscaling, FXAA/SMAA, touch controls,
  physical controllers and gyro. The app offers a Vulkan driver selector and compatibility settings.
- **Frame generation (LSFG), optional:** Lossless Scaling's frame generation with your own `Lossless.dll` (Lossless
  Scaling for Windows, not included; put it in `Download/`, `LSFG/` or `Documents/Emulation/bios/`), 2x-4x, in Video. The
  frame generation code is GPL-3.0-or-later, so **an APK built with it is GPL-3.0-or-later as a whole**: see
  [NOTICE.md](NOTICE.md).
- **0.3.0:** crashes and freezes after 30+ minutes on Mali GPUs, the fast travel's dissolve, stray leaves on the
  ground, the stable's windows and the loading screens in unlocked aspect, a 40 / 45 fps frame rate, even 30 fps on
  60 Hz screens, touch buttons for the arrows and the album, and two Driver compatibility options: the driver's own
  variables, and game memory through a shared file for Mali and Xclipse (experimental).
- **0.3.2:** fewer crashes with the Slate's camera, the red shadows on the Adreno 840 fixed, the unlocked-aspect HUD
  without jumps after a pause, the scope with bars and the inventory without flicker, an option to keep the minimap
  at the bottom with touch controls, and the aim steady when the phone turns round.
- **0.3.3:** fewer crashes after long sessions on Mali, the black grass on Mali fixed, and less memory used on phones
  with under 6 GB of RAM.
- **0.3.4:** the low-RAM profile now activates automatically only on devices with up to 4 GB of RAM. Devices with 6 GB
  return to the normal texture, buffer and cache settings; the manual override remains available.
- **0.4.0:** optional frame generation (LSFG, with your own `Lossless.dll`), a new overlay (compact / detailed, with
  charts), the frame rate no longer stuck lower after a menu or a save, and the pipeline limit on Xclipse and every
  other non-Adreno GPU.
- **0.4.1:** a faster low-RAM mode on 4 GB devices (Galaxy Tab A9+: ~5 to 11-15 fps in the world, without the
  missing ground or the flickering menu letters), vibration on a controller's motors or the phone's, 30 fps while
  the phone overheats, the game paused in the background, and 4:3 / 16:10 screens with bars instead of a squeezed
  image.
- **0.4.2:** faster on Turnip phones where the GPU waited on the CPU (Galaxy Tab A9+: ~15 to ~19 fps in the world),
  RAM saving chosen in Video (Automatic / On / Off), and Auto output at 720p when RAM saving is on.
- **0.4.3:** frame generation asks Android for the refresh rate its frames need (60 fps x 2: 120 Hz), so it works
  on fast screens Android kept at 60 Hz; the menu says when no generated frame fits.
- **0.4.4:** back at full speed right after a menu (~12 s slower after each one before), no long stays at 20 fps
  after a hitch, frame generation on GPUs without null descriptors (Mali), and an Import Lossless.dll button.
- **0.4.5:** shaders freed when the game restarts and, on Mali and other non-Adreno GPUs, after minutes unused
  (#450); a lighter FXAA and FSR 1; Native Mode's clock right on MediaTek phones; the game's auxiliary audio and 3D
  reverb (ports from TOTKDroid).
- **0.4.6:** water that lost its collision after a while (#296), back at full speed 1 s after a load instead of
  10 (#465), touch controls a fingerprint sensor hid (#477), no crash with the movies or the DLC's file missing or
  damaged, safer locks in Native Mode on 1.0.0 / 1.6.0, bilinear filtering on Mali GPUs that lack it for some
  formats, and optional pipeline prewarming.
- **0.4.7:** the dark map and minimap with RAM saving on (#471 #478), a Video > Shadows option, Frame rate 40 / 45
  from the screen's highest refresh rate, fewer shader stalls (urgent builds first, a translation cache), Mali
  texture slots without stalls, and a freeze report in the log (#401).
- **0.4.8:** fixes for game threads that could wait forever (timed waits survive a clock change, a cancelled wait
  no longer looks like a taken lock), a freeze report that shows where the game's main thread is (#401), texture
  slots without stalls on every GPU, and Mali compute work chained without extra barriers.
- **0.4.9:** Settings > Switch-style core turns (experimental, off), for the freeze after a few minutes (#401);
  a fuller freeze report; Unlocked aspect on screens squarer than 16:9 (#474); and Mali shader constants copied
  only where they change.
- **0.4.10:** a fix for the freeze after a few minutes on Mali and Qualcomm's stock driver (#401): what
  shaders write goes back into the game's memory word by word, without undoing the game's own writes.
- **0.4.11:** on an Adreno 6xx with 8 GB of RAM or less, Automatic leaves the game's memory off the GPU, so the
  game no longer closes after a few minutes for lack of GPU memory (#520); a pipeline that fails for lack of memory
  is created again instead of being lost.
- **0.4.12:** Settings > Controls > **Controller gyro axes** for controllers whose gyroscope reports its axes in
  another order (#511, #521); **Wait for the screen (FIFO)** on the start screen, on by default for Adreno 7xx, where
  the picture froze while the game went on (#367); the minimap-at-top group no longer jumps up and down in shrines
  (#261); Mali: less memory-mapping growth from write tracking and 16 / 8-bit integer targets drawn right; PRs #507,
  #537 and #480.
- **0.4.13:** a fix for the freeze after a few minutes of fights on Mali (#401): what shaders write goes back into the
  game's memory word by word without undoing the game's own writes, now also on Malis without the global-memory
  arena; Mali: draw-target reads in place on Automatic (#549), classic render passes on r49+ drivers (PR #534) and
  compressed textures decoded on 4 threads (PR #531).
- **Known issues:** short grass appears only up close; water reflections can move with the camera; the pause menu
  background can be black on Qualcomm's stock driver; Link may flicker on the first hit in Native Mode; rain falls
  slower than on the console.

> [!IMPORTANT]
> Like LAS Recomp, this project is made almost entirely with AI (Claude, by Anthropic, through Claude Code), directed,
> tested and reviewed by a human.

> [!NOTE]
> **No game files or DLC are included.** You need your own legally obtained, extracted game files (`exefs` and
> `romfs`). The app does not open NSP/XCI files or use `prod.keys`. Instructions on obtaining game files are not
> provided.

## Experimental NSP/XCI inspection (Android)

The **Game files** settings include experimental actions to select an NSP/XCI package and a file named
`prod.keys`. This build recognizes the PFS0 signature in NSP containers and lists a sample of entry names
and sizes; for XCI, it recognizes the `HEAD` header signature. This is metadata-only inspection: it does
not open protected NCA content, use keys, decrypt, or extract games. When a `prod.keys` file is selected,
only its access reference and basic metadata are stored; its contents are not read. Selecting a keys file
does not enable protected-package import.

The existing `exefs/` and `romfs/` folder setup remains unchanged and is still the only implemented game
setup workflow. NSP/XCI inspection is experimental and does not convert packages into `exefs/`/`romfs/`.

## Touch Controls Overhaul

Since **0.2.12-beta**, the touch controls show what each button does while you play in the world, with the game's own
icons read from your game files. The game's menus keep the classic buttons.

![Touch controls in the world](docs/images/touch-controls-overhaul.jpg)

- **Your gear on the buttons:** attack, the bow and the shield show what you have equipped, and power shows the selected
  rune (1.6.0, 1.8.2 and 1.9.0).
- **Rune fan:** tap power to use the rune; hold it to open a fan of your runes and let go over the one you want.
- **Gestures:**
  - **Bow and throw:** hold and drag the same finger to aim (with motion controls on, move the phone instead); its sensitivity is in Controls.
    While you hold them, a ✕ cancels the shot or the throw; with the bow drawn, an arrow button picks the arrows.
  - **Parry:** slide the finger on the held shield.
  - **Magnesis and the camera:** with Magnesis selected, a d-pad cross moves the object; with the camera rune, a − button
    opens the album.
  - **Camera:** drag anywhere on the right half.
  - **Weapon and shield pickers:** hold, then choose with a second finger.
  - **Shield surfing:** double-tap the shield and hold.
- **Minimap at the top:** while the touch controls are on screen, the minimap, time, temperature and sensor move to the
  top right corner. With a controller they stay in their usual place. Double-tap the minimap to open the map; the Sheikah Slate
  button opens the scope.
- **Your own layout:** in **Controls**, edit the action layout or the classic one. Drag the buttons, and select one to
  make it bigger or smaller with **−** and **+**.

![Rune fan](docs/images/touch-controls-overhaul-runes.jpg)

## Installing (beta)

1. Download the APK from [Releases](https://github.com/mamcjr/BOTWRecompAndroid/releases) and install it (Android 11+,
   ARM64 and Vulkan). You need your own extracted game folder containing `exefs` and `romfs`.
2. In **Game Files**, choose **Game code**: **Native (experimental)** skips the on-phone code build; **Recompiled**
   builds it once. Under **Game files**, choose **Copy them** or **Use them in place**, then select the extracted folder.
   In-place use asks for Android all-files access; keep that folder where it is. Copying needs roughly 16 GB more
   storage for the game data, while Recompiled Mode also needs space for generated code.
3. If you own the Expansion Pass, install its extracted DLC `romfs` through **Settings > DLC > Install DLC**. To bring
   over saves, use **Settings > Saves** to import a ZIP or emulator save folder.
4. On Adreno phones, a Mesa Turnip driver can perform better than the system driver. Select it under **Settings >
   Files > Vulkan driver**. If the app reports that the Vulkan driver is too old at startup, long-press the app icon
   and choose **Choose driver** before launching the game.

Updating from 0.2.x to 0.4.13-beta does not require rebuilding game code. Shaders compile again once, so the first
minutes may stutter. To report a problem, open an [issue](https://github.com/mamcjr/BOTWRecompAndroid/issues) with
your phone, GPU, driver, game version and a log from **Settings > Files > Save a log file**.

## Testing on Android (developers)

With the Android SDK / NDK, a phone on adb and your dump in `Dump/`:

```bash
cd android/botwrecompandroid && ./gradlew assembleDebug    # the app
android/build_gamelib.sh Dump/01007EF00011E000/exefs  # the game code (about an hour)
android/push_game.sh Dump/01007EF00011E000           # game files and game code onto the phone
android/run_boot.sh 120                               # start the game, log to android/out/boot.log
```

## Support the project

BOTWRecompAndroid is a free, independent project. If you enjoy it and would like to support its development, you can
sponsor me on GitHub, Ko-fi, Buy Me a Coffee or via **Pix**. Your support helps me dedicate time to fixing bugs, improving performance and compatibility, and
working on future releases. Sponsorship is entirely optional: it does not unlock features or guarantee specific fixes.
Bug reports, device tests, and contributions are also greatly appreciated.

Current goal: buy a **POCO X7 Pro ($455)**, a test device equipped with a MediaTek Dimensity SoC and Mali GPU to improve testing and optimize performance across all our ports (BOTWRecompAndroid, TOTKDroid, LASRecompAndroid, and Swap2-Native). The badge below shows total donations received across all platforms; I update it by hand.

[![POCO X7 Pro goal](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fraw.githubusercontent.com%2Fmamcjr%2FBOTWRecompAndroid%2Fmain%2F.github%2Fdonation-goal.json&query=%24.raised&prefix=%24&color=2EA043&logo=xiaomi&logoColor=white&label=POCO%20X7%20Pro%20goal&suffix=%20%2F%20%24455)](https://github.com/mamcjr/BOTWRecompAndroid/blob/main/.github/donation-goal.json)

[![Sponsor on GitHub](https://img.shields.io/badge/Sponsor-on%20GitHub-EA4AAA?logo=githubsponsors&logoColor=white)](https://github.com/sponsors/mamcjr)
[![Ko-fi](https://img.shields.io/badge/Ko--fi-mamcjr-FF5E5B?logo=kofi&logoColor=white)](https://ko-fi.com/mamcjr)
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-mamcjr-FFDD00?logo=buymeacoffee&logoColor=black)](https://buymeacoffee.com/mamcjr)
[![Pix](https://img.shields.io/badge/Pix-Random%20Key-32BCAD?logo=pix&logoColor=white)](#support-the-project)

> **Pix (Brazil only — random key):** `6c326b56-6caf-4c3a-bcf7-1fa8ad2abd16`

## Credits

- [peiikai](https://github.com/peiikai) for [LAS Recomp](https://github.com/peiikai/LASRecomp), the recompiler and
  runtime this project starts from (MIT, see [LICENSE](LICENSE)). The original README is kept in [docs/las/](docs/las/).
- [LASRecompAndroid](https://github.com/mamcjr/LASRecompAndroid), its Android port: the app, the phone-side game code
  build, touch controls, mods, driver compatibility and the Portuguese menus.
- [Revivedx](https://github.com/Revivedx) for [SavageWindRecomp](https://github.com/Revivedx/SavageWindRecomp) (MIT),
  the reference for 1.8.2: frame pacing, internal resolution, the SDK 20 kernel fixes, setjmp.
- [Nycolazs](https://github.com/Nycolazs) for LASRecomp-Android-Plus (MIT): Vulkan driver compatibility.
- [ly05010419](https://github.com/ly05010419) for [MacNativeGames](https://github.com/ly05010419/MacNativeGames) (MIT),
  whose fixes and notes for BOTW and TOTK pointed the way for several here: the sync lag (its PR #680), GPU results
  the CPU reads back (PR #239), the terrain's height map texture (PR #511), texture layout, and the gyroscope's drift;
  and for showing that the game's own ARM64 code can run directly (Native game code).
- [OJZen](https://github.com/OJZen) for [totk-mobile](https://github.com/OJZen/totk-mobile), and
  [jhaizhou-ops](https://github.com/jhaizhou-ops) for [d2r-mobile](https://github.com/jhaizhou-ops/d2r-mobile), the
  core it builds on: what the native mode rewrites in the game's code (`svc`, the thread registers, the counter) and
  how - the idea behind ours (no code taken).
- The [zeldaret/botw](https://github.com/zeldaret/botw) decompilation and [open-ead/sead](https://github.com/open-ead/sead),
  for what is known about the game's code.
- Dusklight's launcher, the start screen's style.
- Upscaling and anti-aliasing: [AMD FidelityFX FSR 1](https://github.com/GPUOpen-Effects/FidelityFX-FSR) (MIT),
  [Qualcomm Snapdragon GSR](https://github.com/SnapdragonStudios/snapdragon-gsr) (BSD-3-Clause),
  [SMAA](https://github.com/iryoku/smaa) (MIT).
- Libraries: [SDL](https://libsdl.org) (zlib), [Dear ImGui](https://github.com/ocornut/imgui) (MIT),
  [libadrenotools](https://github.com/bylaws/libadrenotools) (BSD-2-Clause), [volk](https://github.com/zeux/volk) (MIT),
  [Vulkan Memory Allocator](https://github.com/GPUOpen-LibrariesAndSDKs/VulkanMemoryAllocator) (MIT),
  [shaderc](https://github.com/google/shaderc) (Apache 2.0), [FFmpeg](https://ffmpeg.org) (LGPL),
  [LZ4](https://github.com/lz4/lz4) (BSD-2-Clause), [Capstone](https://www.capstone-engine.org) (BSD-3-Clause),
  [Unicorn](https://www.unicorn-engine.org) (GPLv2, built from its source by `android/deps/build_unicorn.sh`),
  [Python](https://www.python.org) (PSF) and [Zig](https://ziglang.org) (MIT) for the phone-side build.
- [Mesa](https://www.mesa3d.org)'s Turnip driver (MIT), which players load themselves.
- Fonts: [Baloo 2](https://github.com/EkType/Baloo2) (OFL), DejaVu Sans (Bitstream Vera license). The Android robot
  is reproduced or modified from work created and shared by Google (CC BY 3.0).
- Contributions through pull requests:
  - [3122380113](https://github.com/3122380113): builds without FFmpeg again
    ([#97](https://github.com/mamcjr/BOTWRecompAndroid/pull/97)); sound that came back silent after the app sat in the
    background ([#96](https://github.com/mamcjr/BOTWRecompAndroid/pull/96)).
  - [todwang96](https://github.com/todwang96): the GPU heap kept on for Adreno 7xx under Turnip, blank text otherwise
    ([#103](https://github.com/mamcjr/BOTWRecompAndroid/pull/103)).
  - [Ureta93](https://github.com/Ureta93): settings files saved with Windows line endings
    ([#187](https://github.com/mamcjr/BOTWRecompAndroid/pull/187)).
  - [Propinbo](https://github.com/Propinbo): Link breaking up into light again on a fast travel, instead of turning flat
    blue and vanishing ([#210](https://github.com/mamcjr/BOTWRecompAndroid/pull/210)); 30 fps frames shown evenly on
    60 Hz screens, no more 50 / 16.7 ms judder ([#183](https://github.com/mamcjr/BOTWRecompAndroid/pull/183)); no
    validation errors from points and empty copies ([#255](https://github.com/mamcjr/BOTWRecompAndroid/pull/255)); a
    built-in benchmark ([#278](https://github.com/mamcjr/BOTWRecompAndroid/pull/278)).
  - [ilovz73ai-sketch](https://github.com/ilovz73ai-sketch): phone motion on a foldable's inner screen
    ([#284](https://github.com/mamcjr/BOTWRecompAndroid/pull/284)).
  - [3122380113](https://github.com/3122380113): the debug frame's three-finger tap with the touch controls hidden
    ([#252](https://github.com/mamcjr/BOTWRecompAndroid/pull/252)).
- Made with [Claude Code](https://claude.com/claude-code) (Anthropic).

*The Legend of Zelda* and *Breath of the Wild* are trademarks of Nintendo. This project is not affiliated with or
endorsed by Nintendo.
