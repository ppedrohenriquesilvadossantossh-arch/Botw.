// User settings (botwrecompandroid.ini next to the executable's working directory), edited from the in-game menu.
#pragma once
// the performance overlay's items (Settings.overlay_items, ui/perf_overlay.mm)
enum { OVERLAY_FPS = 1, OVERLAY_THROTTLE = 2, OVERLAY_GPU = 4, OVERLAY_CPU = 8, OVERLAY_BATTERY = 16, OVERLAY_MEMORY = 32,
       OVERLAY_ALL = 63 };
#include <stdbool.h>

enum { ASPECT_UNLOCKED = 0, ASPECT_ORIGINAL = 1 };
enum { RES_MATCH = 0, /* 1..8 = 1x..8x */ RES_DYNAMIC = 9, RES_Q75 = 10, RES_Q25 = 11, RES_Q50 = 12 };
// (11 was 67% of the display: larecomp.ini "67%" now loads as RES_Q75)
enum { OUT_AUTO = -1 };  // (Settings.out_lines)
enum { UPSCALE_BILINEAR = 0, UPSCALE_METALFX = 1 /* macOS */, UPSCALE_FSR1 = 2 /* AMD FSR 1 */,
       UPSCALE_SGSR1 = 3 /* Vulkan: Snapdragon Game Super Resolution 1 */ };
#ifdef __APPLE__
#define UPSCALE_SHARP UPSCALE_METALFX  // each OS's non-bilinear upscaler (the default)
#else
#define UPSCALE_SHARP UPSCALE_FSR1
#endif
enum { AA_OFF = 0, AA_SMAA = 1, AA_FXAA = 2 };
// System language served to the game (runtime/services/am.c GetDesiredLanguage, services/hid_set.c GetLanguageCode):
// the game picks its text language from it, as it would from the Switch's own system setting. LANG_AUTO follows the
// host locale ($LC_ALL / $LC_MESSAGES / $LANG); the rest are the codes of the languages the game has text for.
enum { LANG_AUTO = 0, N_LANGUAGES = 15 };
extern const char *const g_language_codes[N_LANGUAGES];  // what the game is told: "ja", "en-US", "es", ...
extern const char *const g_language_names[N_LANGUAGES];  // for the menu ("Auto", "Japanese", ..., "Spanish")

typedef struct {
    int aspect;          // ASPECT_*: unlocked = fill the window (wider/taller views), original = 16:9 with bars
    bool fullscreen;
    int res_mode;        // RES_MATCH, 1..4 (N x the Switch's 1080p), RES_DYNAMIC, RES_Q75/50/25 (share of the display)
    int upscaler;        // UPSCALE_*: how a lower internal resolution reaches the window (MetalFX: macOS, FSR 1: Windows)
    int out_lines;       // Output resolution: the final image (scene + HUD) at most this many lines, scaled up to the
                         // screen at the end (0: the screen's own; 1080 / 900 / 720; OUT_AUTO: 1080 on taller
                         // screens, Android's default) - nvn/output_scale.c
    int antialias;       // AA_*: anti-aliasing of the game image before it is scaled to the window
    bool shadows;        // the game's shadows drawn (off: their draws skipped - a flatter picture, a little less GPU
                         // work; vulkan/exec.c)
    float volume;        // master volume, 1 = 100%
    bool reverb;         // room reverb effect
    bool movie_audio;
    bool show_fps;
    bool motion;          // the phone's (or a controller's) gyroscope as the controller's motion sensor (hle/motion.c)
    int motion_source;    // whose: 0 automatic (a controller's once its gyroscope is alive), 1 the phone's, 2 a controller's
    int pad_gyro_axes;    // a controller's gyroscope axis order: 0 as reported, 1 y,x,z, 2 z,y,x, 3 x,z,y (hle/motion.c, #511)
    bool lsfg; int lsfg_mult, lsfg_flow;  // frame generation (vulkan/lsfg): on, frames per game frame 2..4, motion resolution % (0: the game's)
    bool motion_flat;     // the phone's sensors as the Switch's screen in handheld mode, not a flat controller (hle/motion.c)
#ifdef __ANDROID__
    bool touch_controls;  // on-screen controls while no controller is connected (ui/touch_controls.mm)
    int overlay_style;    // Show FPS's overlay (ui/perf_overlay.mm): 0 full, 1 compact (one line)
    int overlay_scale, overlay_opacity;  // its size and opacity, % (40..150, 20..100)
    int overlay_items;    // OVERLAY_* bits: what it shows (all by default)
    float overlay_pos[2]; // its top left, a share of the screen, dragged there with a finger (negative: the corner)
    bool event_fps_unlock;  // in-game cutscenes and talks at the chosen frame rate, not 30 (hle/framepace.c)
    int fps_mode;         // 0: the game's own choice (30 / 60, the frame pacer), 1: 30 fps, 2: 60 fps, 3: 20 fps, 4: 45 fps
                          // (what runs: fps_mode_now - 30 while the phone overheats, thermal_cap)
    bool thermal_cap;     // Android: 60 (or 40 / 45) fps drop to 30 while Android says the phone is too hot (hle/framepace.c)
    bool shader_int32;    // shader address math in 32-bit words even where the driver offers 64-bit (vulkan/exec.c)
    bool native_code;     // Android: the game's own code on the CPU, no build of it (runtime/native.c); off by default
    bool pipe_prewarm;    // Android: recorded graphics pipelines built while a save loads (vulkan/exec.c; experimental, off by default)
    bool core_turns;      // Android: the threads of each core take turns, not only core 0's (kernel.c core0_init: mask 7,
                          // as LARECOMP_CORE_LOCKS=7, which overrides it; #401; experimental, off by default)
    bool files_in_place;  // Android: a setup reads the picked romfs/ where it is, no copy (services/fs.c); off by default
    bool sync_lag;        // Android: the game's next frame overlaps the GPU's last (nvn/objects.c nvnSyncWait); on by default
    int low_ram;          // RAM saving (vulkan/exec.c vk_low_ram): -1 automatic (devices up to 4 GB), 1 on, 0 off; read once,
                          // as the app starts
    // Driver compatibility (the start screen's Settings > Prelaunch, ui/launcher.mm; from LASRecompAndroid), for GPUs
    // where a Turnip path draws wrong: read when the game starts (gpu_heap, inplace_reads) or when the app starts
    // (turnip_lrz, log_file). -1 Automatic: on for the Adreno 8xx GPUs these paths were made on, off elsewhere
    // (vulkan/device.c vk_adreno_8xx); 1 on, 0 off.
    int gpu_heap;         // Turnip: the game's memory mapped as GPU memory (vulkan/exec.c vk_heap_place); off: CPU copies
                          // (its Automatic: on for any Turnip that can place it - vulkan/device.c vk_turnip_heap_on)
    int inplace_reads;    // Turnip (Automatic on 8xx) and Mali (Automatic on, #549): draws sample targets they write as they are (vulkan/exec.c resolve_feedback); off: copies
    int turnip_lrz;       // Turnip's low-resolution Z; off: TU_DEBUG=nolrz before the driver loads (vulkan/device.c)
    int present_fifo;     // the swapchain's present mode: 1 FIFO (each image waits for the screen), 0 MAILBOX; -1
                          // Automatic: FIFO on Adreno 7xx (#367: the picture froze with MAILBOX while the game ran on),
                          // MAILBOX elsewhere (vulkan/device.c present_mode; LARECOMP_VK_PRESENT over it)
    int dyn_render;       // Vulkan dynamic rendering: 1 on, 0 classic VkRenderPass, -1 Automatic (off on ARM Mali r49+,
                          // on elsewhere: vulkan/device.c); LARECOMP_NO_DYNAMIC_RENDERING over it; restart to apply
    bool log_file;        // the log in a file as well (platform/android.c), to send with a report
    char gpu_model[64];   // the GPU of the last start ("Adreno (TM) 830v1"): turnip_lrz's Automatic, before the driver
    bool heap_file;       // the game's memory as GPU memory through an exported file mapped at its address, where the driver
                          // can't place it (Mali, Xclipse; experimental): vulkan/exec.c vk_heap_place, at the game's start
    char driver_env[256]; // the driver's own switches, NAME=value separated by spaces (Turnip's FD_DEV_FEATURES, TU_DEBUG;
                          // #227): set when the app starts, before the driver loads (vulkan/device.c)
#define TOUCH_NCTL 19  // (ui/touch_controls.mm: LAS's 12, then the right stick, L3 / R3 and the d-pad)
    float touch_pos[TOUCH_NCTL][2];  // each on-screen control's place, a share of the screen (negative: default)
    // The icon layout (ui/touch_controls.mm), in the world only - the classic one above stays in the game's menus:
    // touch_scheme 1 (0: the classic one everywhere), its controls' places of their own
#define TOUCH_NCTL2 24
    int touch_scheme;
    float touch_pos2[TOUCH_NCTL2][2];
    float touch_size[TOUCH_NCTL], touch_size2[TOUCH_NCTL2];  // each control's own size (times touch_scale; 0: 1)
    float touch_aim_sens;  // the icon layout's bow / throw drag: how fast it turns the aim (1: the default)
    bool touch_minimap_top;  // the minimap group up at the top while the touch controls are up (#254: off keeps it in place)
    bool touch_talk;       // the icon layout gives way to a talk: only the stick, A and B (false: all its controls stay)
    float touch_scale, touch_opacity;
    // FPS-style touch play (ui/touch_controls.mm): the camera by dragging a finger (its speed tilts the right stick)
    // instead of holding a stick, at touch_drag_sens; the sticks drawn only while a finger holds them; each stick's
    // area a whole half of the screen
    bool touch_drag_camera, touch_sticks_hidden, touch_half_areas;
    float touch_drag_sens;
    float stick_deadzone;  // a controller's sticks: a round dead zone (share of the travel, 0-0.4), rescaled past it
                           // (hle/input.c): worn sticks that drift. 0: the game's own only
    int vibration;         // a controller's rumble from the game's vibration (hle/input.c), % (0: off; 100 by default)
    bool vibration_phone;  // the phone's own motor where no controller has one (hle/input.c; off by default)
#endif
    int language;        // LANG_AUTO or an index into g_language_codes: the game's text language
    bool aspect_asked;   // the start screen's one-time "authentic 16:9 or unlocked?" question was answered
    bool menu_tip_seen;  // the start screen's one-time "how to open the menu" note was shown (first PLAY ever)
    char mods_off[512];  // game mods turned off (runtime/mods.c: their folder names, separated by '|')
} Settings;

extern Settings g_settings;

// The frame rate mode in effect (hle/framepace.c): g_settings.fps_mode, or 1 (30 fps) while the thermal cap holds a
// 60 or 40 / 45 fps mode down. What the pacer, the swap interval and the resolution go by; the menus show the setting.
int fps_mode_now(void);
void framepace_thermal_sample(int thermal, float headroom);  // (once a second, from the activity: platform/android.c)
void settings_load(void);
void settings_save(void);
// The menu's RESTORE DEFAULTS: the Video and Audio options back to the defaults (the language, the controls, the touch
// layout, mods and the one-time questions stay)
void settings_reset_defaults(void);
// The language code to serve the game ("es", "en-US", ...): the setting, or the host locale for LANG_AUTO
const char *settings_language(void);
// That code's name for the menu ("Spanish")
const char *settings_language_name(void);
// Android: the language of the menus' own text (ui/i18n.mm), from the phone's first preferred language: "pt", "es", "fr",
// "de", "it", "nl", "ru", "ja", "ko", "zh-Hans", "zh-Hant" (the game's languages), else "en". LARECOMP_HOST_LANG=<code>
// (tests). Elsewhere "en".
const char *settings_menu_language(void);
bool settings_host_portuguese(void);  // (settings_menu_language is "pt")
